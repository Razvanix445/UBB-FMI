package interfacesExample;

public class Robot extends Character implements CanTalk{
    @Override
    public void talk() {

    }

}
