package interfacesExample;

public interface CanFly extends CanPlay{
    public void fly();
}
