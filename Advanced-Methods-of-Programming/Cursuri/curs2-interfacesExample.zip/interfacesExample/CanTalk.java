package interfacesExample;

public interface CanTalk extends CanPlay{
    void talk();
}