package interfacesExample;

public interface CanPlay {
    //void play();
}
