package ro.ubb.reflection;

import java.lang.reflect.*;
import java.util.Arrays;

/**
 * <p>
 * * 1.
 * * - create a new "ro.ubb.reflection.Student" instance (reflection).
 * * - initialize the student's private attributes ("name", "groupNumber") with the values ("john", 123).
 * * - print the student instance.
 * * <p>
 * * 2.
 * * - create a new "ro.ubb.reflection.Student" instance (reflection)
 * * - invoke setName("john") and setGroupNumber(123)
 * * - print the student instance.
 * * <p>
 * * 3.
 * * - create a new "ro.ubb.reflection.Student" instance ("john",123) by invoking the constructor
 * * - print the student instance.
 * * <p>
 * * 4.
 * * - create a new "ro.ubb.reflection.Employee". ("ro.ubb.reflection.e04.Employee" extends "ro.ubb.reflection.Person", Person has a
 * * name, Employee has a salary) (reflection)
 * * - set the "name" to "Mary" and the "salary" to 1000;
 * * - print the employee
 * * <p>
 * * 5.
 * * - given a Student instance ("John",123), print all attribute names, types, and values.
 */



public class Main {

    public static void reflectClass(Class aClass) {
        String lines = "";
        lines += String.format("Class " + aClass.getName() + " having the following members:\n");

        for (Field aField : aClass.getDeclaredFields()) {
            lines += String.format("\tField name -  %s :%s\n", aField.getName(), aField.getType());
        }
        for (Method aMethod : aClass.getDeclaredMethods()) {
            lines += String.format("\tMethod name -  %s (): %s\n", aMethod.getName(), aMethod.getReturnType().getName());
            Parameter[] param = aMethod.getParameters();
            for (int i = 0; i < param.length; i++) {
                lines += String.format("\t\t Param  %d - %s:%s\n", i + 1, param[i].getName(), param[i].getType());
            }
        }
        for (Constructor aConstructor : aClass.getConstructors()) {
            lines += String.format("\tConstructor name - %s:", aConstructor.getName());
            for (int i = 0; i < aConstructor.getParameters().length; i++) {
                Parameter param = aConstructor.getParameters()[i];
                lines += String.format("\t\t Param -  %d: %s :%s\n", i + 1, param.getName(), param.getType());
            }
        }
        System.out.println(lines);
    }


    public static void main(String[] args) throws Exception {
        System.out.println("bye");


        Class s=Student.class;



        p1();
        p2();
        p3();
        p4();
        p5();
    }

    private static void p5() {
        Student student = new Student("john", 123);

        Field[] fields = student.getClass().getDeclaredFields();
        Arrays.stream(fields).forEach(field -> {
            field.setAccessible(true);
            System.out.println(field.getName());
            System.out.println(field.getType());
            try {
                System.out.println(field.get(student));
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        });

    }

    private static void p4() throws ClassNotFoundException, IllegalAccessException, InstantiationException, NoSuchFieldException {
        Class employeeClass = Class.forName("ro.ubb.reflection.Employee");
        Employee employee = (Employee) employeeClass.newInstance();

        Field salaryField = employeeClass.getDeclaredField("salary");
        salaryField.setAccessible(true);
        salaryField.set(employee, 1000);

        Field nameField = employeeClass.getSuperclass().getDeclaredField("name");
        nameField.setAccessible(true);
        nameField.set(employee, "mary");

        System.out.println(employee);


    }

    private static void p3() throws ClassNotFoundException, NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
        Class studentClass = Class.forName("ro.ubb.reflection.Student");

        Constructor studentConstructor =
                studentClass.getDeclaredConstructor(String.class, int.class);


        Object student = studentConstructor.newInstance("john", 123);

        System.out.println(student);

    }



    private static void p2() throws Exception {
        Class studentClass = Class.forName("ro.ubb.reflection.Student");
        Student student = (Student) studentClass.newInstance();

        Method setNameMethod = studentClass.getMethod("setName", String.class);
        setNameMethod.invoke(student, "john");

        Method setGroupNumberMethod = studentClass.getMethod("setGroupNumber", int.class);
        setGroupNumberMethod.invoke(student, 914);

        System.out.println(student);

    }


    private static void p1() throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchFieldException {
        Class studentClass = Class.forName("ro.ubb.reflection.Student");
        Student student = (Student) studentClass.newInstance();

        Field nameField = studentClass.getDeclaredField("name");
        nameField.setAccessible(true);
        nameField.set(student, "John");
        nameField.setAccessible(false);

        Field groupField = studentClass.getDeclaredField("groupNumber");
        groupField.setAccessible(true);
        groupField.setInt(student, 123);
        groupField.setAccessible(false);

        System.out.println(student);
    }


}
