package ro.ubb.reflection;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;

/**
p1.
 * * - create a new "ro.ubb.reflection.Student" instance (reflection).
 * * - initialize the student's private attributes ("name", "groupNumber") with the values ("john", 123).
 * * - print the student instance.


p2.
 * * - create a new "ro.ubb.reflection.Student" instance (reflection)
 * * - invoke setName("john") and setGroupNumber(123)
 * * - print the student instance.


p3.
 * * - create a new "ro.ubb.reflection.Student" instance ("john",123) by invoking the constructor
 * * - print the student instance.

p4.
 * * - given a Student instance ("John",123), print all attribute names, types, and values.
 */
public class Main2 {
    public static void main(String[] args) throws NoSuchFieldException, ClassNotFoundException, InstantiationException, IllegalAccessException, InvocationTargetException, NoSuchMethodException {
        p2();

    }

    private static void p3() {


    }

    /**
     * p1.
     *  * * - create a new "ro.ubb.reflection.Student" instance (reflection).
     *  * * - initialize the student's private attributes ("name", "groupNumber") with the values ("john", 123).
     *  * * - print the student instance.
     */
    private static void p1() throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchFieldException {
        Class cls = Class.forName("ro.ubb.reflection.Student");
        Student student = (Student) cls.newInstance();

        Field nameField = cls.getDeclaredField("name");
        Field groupField = cls.getDeclaredField("groupNumber");

        nameField.setAccessible(true);
        nameField.set(student, "john");
        nameField.setAccessible(false);

        groupField.setAccessible(true);
        groupField.set(student, 123);
        groupField.setAccessible(false);

        System.out.println(student);
//        Constructor constructor = cls.getConstructor();
//        constructor.newInstance("john",123);
    }

    public static void p1_1() throws NoSuchMethodException, ClassNotFoundException, InvocationTargetException, InstantiationException, IllegalAccessException {
        Class cls = Class.forName("ro.ubb.reflection.Student");
        Constructor constructor = cls.getConstructor(String.class, int.class);
        Student student = (Student) constructor.newInstance("john",123);
        System.out.println(student);
    }

    public static void p1_2() throws NoSuchMethodException, ClassNotFoundException, InvocationTargetException, InstantiationException, IllegalAccessException {
        //NU MERGE
//        Class cls = Class.forName("ro.ubb.reflection.Student");
//        Constructor constructor = cls.getDeclaredConstructor();
//        Student student = (Student) constructor.newInstance("john",123);
//        System.out.println(student);
    }

    public static void p1_3() throws ClassNotFoundException {
        Class cls = Class.forName("ro.ubb.reflection.Student");
        Constructor[] constructors = cls.getConstructors();
        Arrays.stream(constructors).forEach(x -> System.out.println(Arrays.toString(x.getParameterTypes())));
    }



    private static void p4() {

    }

//    p2.
// * * - create a new "ro.ubb.reflection.Student" instance (reflection)
// * * - invoke setName("john") and setGroupNumber(123)
//            * * - print the student instance.

    private static void p2() throws ClassNotFoundException, NoSuchMethodException, InstantiationException, IllegalAccessException, InvocationTargetException {
        Class<?> cls = Class.forName("ro.ubb.reflection.Student");
        Method setNameMethod = cls.getMethod("setName", String.class);
        Method setGroupMethod = cls.getMethod("setGroupNumber", int.class);

        Student student = (Student) cls.newInstance();

        setNameMethod.invoke(student, "john");
        setGroupMethod.invoke(student, 123);

        System.out.println(student);
    }








}
