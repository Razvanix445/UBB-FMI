package ro.ubb.map.demogui.utils.events;

public interface Event {
}
